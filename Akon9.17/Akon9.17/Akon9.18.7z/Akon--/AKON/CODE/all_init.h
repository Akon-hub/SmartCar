#ifndef _all_init_h_
#define _all_init_h_

#include "headfile.h"

extern uint8 GlobalInit();

#endif
